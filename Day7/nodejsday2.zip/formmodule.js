exports.addition=function(a,b){
    return parseInt(a)+parseInt(b);
}